const mongoose = require('mongoose');
const {isValidPhoneNumber}= require('libphonenumber-js');
const userSchema = new mongoose.Schema({
   firstName: {
        type: String,
        required: [true,"please add firstname"],
      },
   lastName: {
        type: String,
        required:[true,"please add lastname"],
    },
   phoneNumber:{
      type: String,
      required:[true,"please add phone number"],
      validate: {
        validator: function(value) {
          return isValidPhoneNumber(value, 'EG'); 
        },
        message: 'Please enter a valid Egyptian phone number',
      },
    },

  email: {
    type: String,
    required: [true,"please add email"],
    unique: [true,"email address already taken"],
  },
  password: {
    type: String,
    required: [true,"please add password"],
    validate: {
        validator: function(value) {
          // Custom validation logic
          return value.length >= 6; // Return true if the value has at least 6 characters
        },
        message: 'Password must have at least 6 characters'
      }
  },
  role: {
    type: String,
    enum: ['admin', 'user'],
    default: 'user',
  },
  
},
{
  timestamps:true,
}
);

const User = mongoose.model('User', userSchema);

module.exports = User;
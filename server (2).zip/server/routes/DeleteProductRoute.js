const express= require('express');
const router = express.Router();

const { deleteDonut } = require("../controllers/DeleteProduct");
router.route('/deleteproduct/:id').delete(deleteDonut);

module.exports= router;
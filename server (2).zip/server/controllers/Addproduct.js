const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");

//describe Create new donut
//then route whoch would be POST/api/products
//access public and in the future in wouldnt be public 

const createDonut =asynchandler( async(req,res) => {
    console.log("the request body is:",req.body);
    const{name,category,price,description,image} = req.body;
    if(!name || !category || !price ||! description || !image)
    {
        res.status(400);
        throw new Error("All fields are mandatory to be fullfilled")
    }
    const donut= await DonutProduct.create(
        {
            name,
            category,
            price,
            description,
            image,
        });
    res.status(201).json(donut);
});

module.exports = {createDonut}
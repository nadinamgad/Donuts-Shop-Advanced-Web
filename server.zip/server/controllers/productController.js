const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");




//describe get all donuts
//then route whoch would be Get/api/contacts
//access public and in the future in wouldnt be public 
const getDonuts = asynchandler(async(req,res) => {
    const donuts= await DonutProduct.find();
    res.status(200).json(donuts);
});

//describe Create new donut
//then route whoch would be POST/api/products
//access public and in the future in wouldnt be public 
const createDonut =asynchandler( async(req,res) => {
    console.log("the request body is:",req.body);
    const{name,category,price,description,image} = req.body;
    if(!name || !category || !price ||! description || !image)
    {
        res.status(400);
        throw new Error("All fields are mandatory to be fullfilled")
    }
    const donut= await DonutProduct.create(
        {
            name,
            category,
            price,
            description,
            image,
        });
    res.status(201).json(donut);
});
//describe get specfic donut
//then route whoch would be get/api/products/id
//access public and in the future in wouldnt be public
const getSpecficDonut=asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        res.status(404);
        throw new Error("donut not found");
    }
    res.status(200).json(donut);
});
//describe update specfic donut
//then route whoch would be update/api/products/:id
//access public and in the future in wouldnt be public

const updateDonut=asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        res.status(404);
        throw new Error("donut not found");
    }
    const updatedDonut= await DonutProduct.findByIdAndUpdate
    (
        req.params.id,
        req.body,
        {
            new:true
        }
    );
    res.status(200).json(updatedDonut);
});

//describe delete specfic donut
//then route whoch would be delete/api/products/:id
//access public and in the future in wouldnt be public
const deleteDonut= asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        res.status(404);
        throw new Error("donut not found");   
    }
    await DonutProduct.findOneAndRemove()
    res.status(200).json(DonutProduct);
});



module.exports ={ getDonuts,createDonut,getSpecficDonut,updateDonut,deleteDonut}
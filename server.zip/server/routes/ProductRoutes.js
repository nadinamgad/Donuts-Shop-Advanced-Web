const express= require('express');
const router = express.Router();
//const { authenticateUser } = require('../middleware/authenticateUser');
const { getDonuts,createDonut,getSpecficDonut,updateDonut,deleteDonut, } = require("../controllers/productController");
//khaleet el post m3 el get alshan homa nafs el line 7naka meny bdal two linez tb2a line wa7ed
// w 3mlt keda m update w delete
/* badal ma yeb2a shaklhom keda hyb2a shakolom as following
router.route('/:id').put(updateDonut);

router.route('/:id').delete(deleteDonut);
*/
router.route('/').get(getDonuts).post(createDonut);
router.route('/:id').get(getSpecficDonut).put(updateDonut).delete(deleteDonut);

module.exports= router;
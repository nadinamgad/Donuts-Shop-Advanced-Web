const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");

//describe update specfic donut
//then route whoch would be update/api/products/:id
//access public and in the future in wouldnt be public

const updateDonut=asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        console.log("found no donut!");
        res.status(404);
        throw new Error("donut not found");
        
    }
    else{
        console.log("found donut!");
    }
    const updatedDonut= await DonutProduct.findByIdAndUpdate
    (
        req.params.id,
        req.body,
        {
            new:true
        }
    );
    res.status(200).json(updatedDonut);
});

module.exports = {updateDonut}
const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");

//describe get specfic donut
//then route whoch would be get/api/products/id
//access public and in the future in wouldnt be public
const getSpecficDonut=asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        res.status(404);
        throw new Error("donut not found");
    }
    res.status(200).json(donut);
});

module.exports = {getSpecficDonut}
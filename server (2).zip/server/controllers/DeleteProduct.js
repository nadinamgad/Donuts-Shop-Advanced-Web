const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");

//describe delete specfic donut
//then route whoch would be delete/api/products/:id
//access public and in the future in wouldnt be public

const deleteDonut= asynchandler(async(req,res) => {
    const donut= await DonutProduct.findById(req.params.id);
    if(!donut)
    {
        res.status(404);
        throw new Error("donut not found");   
    }
    await DonutProduct.findOneAndRemove()
    res.status(200).json(DonutProduct);
});

module.exports = { deleteDonut }
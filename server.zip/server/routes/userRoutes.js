const express= require('express');
const {registerUser,LoginUser,CurrentUser}= require("../controllers/userController")
const router = express.Router()
// hena bndah 3la el contollers ely shayla yo3tbar el logic bta3y wb7otha fel oprations elmonasba 
router.post("/register",registerUser);
router.post("/login",LoginUser);
router.get("/current",CurrentUser);

module.exports= router;
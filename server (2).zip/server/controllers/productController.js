const asynchandler= require("express-async-handler");
const DonutProduct= require("../models/productModel");


//describe get all donuts
//then route whoch would be Get/api/contacts
//access public and in the future in wouldnt be public 
const getDonuts = asynchandler(async(req,res) => {
    const donuts= await DonutProduct.find();
    res.status(200).json(donuts);
});


module.exports ={ getDonuts}
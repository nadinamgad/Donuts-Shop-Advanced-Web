//make sure u install bcrypt and jsonwebtoken
const asynchandler= require("express-async-handler");
const bcrypt= require("bcrypt");
const jwt= require("jsonwebtoken");
const User= require("../models/userModel");

//Register a user
//then route whoich would be Post/api/users/register
//access public 
const registerUser= asynchandler(async(req,res)=>{
    const {firstName,lastName,phoneNumber,email,password, role}= req.body;
    //we have to check first that they arent empty
    if(!firstName || !lastName || !phoneNumber||!email||!password)
    {
        res.status(400);
        throw new Error("All fields are mandatory!");
    }
    //check if user is already registered with the email
    const userAvailable= await  User.findOne({email});
    if(userAvailable)
    {
       res.status(400);
       throw new Error("user already registered");

    }
    //hashed password
    const hashedPassword = await bcrypt.hash(password, 10);
    console.log("Hashed Password:",hashedPassword);
    //etmna enu kolo tmam, n create el user b2a ely fat da kolo bngrab k validation wise bs lsa 
    //we didn't create haga fel database yet
    const user= await User.create({
        firstName,
        lastName,
        phoneNumber,
        email,
        password:hashedPassword,
        role,
    });
    console.log(`User created successfully${user}`);
    if(user)
    {
        res.status(201).json({_id:user.id,email:user.email});
    }else{
        res.status(400);
        throw new Error("User data isnt Valid");
    }
    res.json({message:"Register the user"});
    
});

//login user a user
//then route which would be Post/api/users/login
//access public and in the future in wouldnt be public 
const LoginUser= asynchandler(async(req,res)=>{
    const {email,password}= req.body;
    if(!email || !password)
    {
        res.status(400);
        throw new Error("All fields are mandatory");
    }
    //our user ely hwa stored fel database
    const user = await User.findOne({ email });
    
    //compare password with hash password
    if(user && (await bcrypt.compare(password,user.password)))
    {

        //201 de m3naha sh8ala meya meya w 400 w 500 tb2a error w msh mazbouta for illustration
        const accessToken = jwt.sign(
            {
              user: {
                firstName: user.firstName,
                lastName: user.lastName,
                phoneNumber: user.phoneNumber,
                email: user.email,
                role: user.role,
                id: user.id,
              },
            },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: '30m' }
          );
       console.log({accessToken});
       res.status(200).json({ accessToken });
    }else{
        res.status(401); //m3nah el pass w email isnt valid w feh moshkla fel cerdentials
        throw new Error("email or password is not valid");
    }
});


//current user
//then route which would be Get/api/users/current
//access private fo the user bs enu ya5od el m3lomat bt3to ely m7tga but i dont think en leha lazma bs 2olt asebha just in case
const CurrentUser= asynchandler(async(req,res)=>{
    res.json({message:" current user information"});
});
// n3mlhom export b2a alshan n3raf n import them fel userRoutes 
module.exports= {registerUser,LoginUser,CurrentUser};
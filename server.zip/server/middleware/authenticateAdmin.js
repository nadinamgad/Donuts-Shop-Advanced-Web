const jwt = require('jsonwebtoken');

const authenticateUser = (req, res, next) => {
  // Get the access token from the request headers or query parameters
  const token = req.headers.authorization?.split(' ')[1] || req.query.token;

  if (!token) {
    return res.status(401).json({ message: 'Unauthorized' });
  }

  try {
    // Verify the access token
    const decoded = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);

    // Check if the user has the admin role
    if (decoded.user.role !== 'admin') {
      return res.status(403).json({ message: 'Forbidden' });
    }

    // User is authenticated and has the necessary role
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Unauthorized' });
  }
};

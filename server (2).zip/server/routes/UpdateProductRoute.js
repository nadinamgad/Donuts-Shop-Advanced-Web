const express= require('express');
const router = express.Router();

const { updateDonut } = require("../controllers/UpdateProduct");
router.route('/updateproduct/:id').put(updateDonut);

module.exports= router; 
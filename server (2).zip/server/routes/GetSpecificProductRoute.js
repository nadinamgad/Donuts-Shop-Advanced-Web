const express= require('express');
const router = express.Router();

const { getSpecficDonut } = require("../controllers/GetSpecificProduct");
router.route('/getSpecificDonut').get(getSpecficDonut);

module.exports= router;
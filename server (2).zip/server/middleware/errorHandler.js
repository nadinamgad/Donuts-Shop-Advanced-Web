const errorHandler= (err,req,res,next) =>{
const statusCode=res.statusCode ? res.statusCode :500;
const {constants} = require("../constants");
switch(statusCode)
{
    case constants.VALIDATION_ERROR:
        res.json ({
        title:"validation failed",
        message:err.messsage,
        stackTrace:err.stack,
    });
     break;
    case constants.NOT_FOUND:
        res.json ({
        title:"not found",
        message:err.messsage,
        stackTrace:err.stack,
     });
     case constants.UNAUTHORIZED:
        res.json ({
        title:"Unauthorized",
        message:err.messsage,
        stackTrace:err.stack,
     });
     case constants.FORBIDDEN:
        res.json ({
        title:"Forbeddien",
        message:err.messsage,
        stackTrace:err.stack,
     });
     case constants.server_error:
        res.json ({
        title:"Server Error",
        message:err.messsage,
        stackTrace:err.stack,
     });
    default:
        console.log("No Error");
        break;


}

};
/*
const authenticateUser = (req, res, next) => {
   // Check if user is authenticated (logged in)
   if (!req.user) {
     return res.status(401).json({ message: 'Unauthorized' });
   }
   
   // Check if user has the necessary role (admin)
   if (req.user.role !== 'admin') {
     return res.status(403).json({ message: 'Forbidden' });
   }
   
   // User is authenticated and has the necessary role
   next();
 };
 */
module.exports= errorHandler;
const express= require('express');
const mongoose= require('mongoose');
const cors = require("cors");
const Product= require('./models/productModel');
const connectDb= require('./config/DBconnection');
const { Console, error } = require("console");
const errorHandler = require('./middleware/errorHandler');
const dotenv= require("dotenv").config();
//connectDb();
const app = express()

const DATABASE_CONNECTION = process.env.DATABASE_URL;
const port = process.env.Port || 5000;
mongoose
  .connect(DATABASE_CONNECTION, {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  })
  .then(() =>{


    app.listen(port,() =>{
        console.log(`connected to Mongo database`)
        console.log(`Node api is running at port ${port}`)
        })
        
        
  }).catch((error) =>
   {console.error(error)});


//adding middleware bta3na
app.use(express.json());

app.use(cors());

// CORS headers
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', 'http://localhost:5173'); // Replace '*' with the specific origin of your frontend
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
  res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
  next();
});


// routes

// app.use("/api/products", require("./routes/ProductRoutes"));
app.use("/api/products", require("./routes/AddProductRoute"));
app.use("/api/products", require("./routes/DeleteProductRoute"));
app.use("/api/products", require("./routes/GetAllProductsRoute"));
app.use("/api/products", require("./routes/GetSpecificProductRoute"));
app.use("/api/products", require("./routes/UpdateProductRoute"));

app.use("/api/users", require("./routes/userRoutes"));
app.use(errorHandler);


// port and DB config

/*
app.post('/product',async(req,res)=>
{
    try{
        const product = await Product.create(req.body)
        res.status(200).json(product);
    } catch(error)
    {
        console.log(error.message);
        res.status(500).json({message: error.message});
    }
})
*/





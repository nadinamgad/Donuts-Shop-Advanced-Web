const express= require('express');
const router = express.Router();

const { createDonut } = require("../controllers/Addproduct");

router.route('/addproduct').post(createDonut);

module.exports= router;